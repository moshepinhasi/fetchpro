// FetchPro Bridge — popup script (v1.3)

const $ = id => document.getElementById(id);

// ── helpers ────────────────────────────────────────────────────────────────

function timeAgo(ts) {
  const diff = Date.now() - ts;
  if (diff < 60_000)    return `לפני ${Math.floor(diff / 1000)} שנ׳`;
  if (diff < 3_600_000) return `לפני ${Math.floor(diff / 60_000)} דק׳`;
  if (diff < 86_400_000)return `לפני ${Math.floor(diff / 3_600_000)} שע׳`;
  return new Date(ts).toLocaleDateString("he-IL");
}

function shortUrl(url) {
  try {
    const u = new URL(url);
    const path = u.pathname.split("/").pop() || u.hostname;
    return path.length > 38 ? path.slice(0, 35) + "…" : path;
  } catch (_) {
    return url.slice(0, 38);
  }
}

// XSS-safe: escape HTML special chars before inserting into attributes/text
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function flash(msg, type) {
  const el = $("flashMsg");
  el.textContent = msg;
  el.className = `flash show ${type}`;
  setTimeout(() => { el.className = "flash"; }, 2800);
}

// ── status polling ─────────────────────────────────────────────────────────

async function refreshStatus() {
  try {
    const { enabled, connected } = await chrome.runtime.sendMessage({ type: "GET_STATUS" });

    const dot = $("connDot");
    const lbl = $("connStatus");
    dot.className   = `dot ${connected ? "connected" : "disconnected"}`;
    lbl.className   = `conn-status ${connected ? "ok" : "err"}`;
    lbl.textContent = connected ? "מחובר ✓" : "לא מחובר ✗";

    $("toggleSwitch").checked = enabled;
  } catch (e) {
    // Service worker may have been killed — ignore
  }
}

// ── history rendering ──────────────────────────────────────────────────────

async function refreshHistory() {
  let history = [];
  try {
    const res = await chrome.runtime.sendMessage({ type: "GET_HISTORY" });
    history = res?.history || [];
  } catch (_) {
    return; // extension context invalidated (e.g. extension reloaded) — ignore
  }
  const list = $("historyList");

  if (!history.length) {
    list.innerHTML = '<div class="empty-history">אין הורדות עדיין</div>';
    return;
  }

  list.innerHTML = history.slice(0, 20).map(item => `
    <div class="history-item" title="${escapeHtml(item.url)}">
      <span class="h-icon">${item.success ? "✅" : "❌"}</span>
      <div class="h-content">
        <div class="h-url">${escapeHtml(shortUrl(item.url))}</div>
        <div class="h-time">${timeAgo(item.timestamp)}${item.error ? " · " + escapeHtml(item.error) : ""}</div>
      </div>
    </div>
  `).join("");

  // Click history item to copy URL to input
  list.querySelectorAll(".history-item").forEach((el, i) => {
    el.style.cursor = "pointer";
    el.addEventListener("click", () => {
      $("urlInput").value = history[i].url;
      $("urlInput").focus();
    });
  });
}

// ── event handlers ─────────────────────────────────────────────────────────

$("toggleSwitch").addEventListener("change", async e => {
  await chrome.runtime.sendMessage({ type: "SET_ENABLED", value: e.target.checked });
  flash(e.target.checked ? "יירוט פעיל ✓" : "יירוט כבוי", e.target.checked ? "ok" : "warn");
});

$("sendBtn").addEventListener("click", async () => {
  const url = $("urlInput").value.trim();
  if (!url) { flash("הכנס קישור", "err"); return; }
  if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("ftp://")) {
    flash("קישור לא תקין — חייב להתחיל ב-http/https/ftp", "err");
    return;
  }

  $("sendBtn").disabled = true;
  $("sendBtn").textContent = "שולח…";

  const { success, error } = await chrome.runtime.sendMessage({ type: "SEND_URL", url });

  $("sendBtn").disabled = false;
  $("sendBtn").textContent = "⬇ שלח";

  if (success) {
    flash("נשלח בהצלחה ✓", "ok");
    $("urlInput").value = "";
    refreshHistory();
  } else {
    flash(error || "שגיאה בשליחה", "err");
  }
});

$("urlInput").addEventListener("keydown", e => {
  if (e.key === "Enter") $("sendBtn").click();
});

$("clearBtn").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "CLEAR_HISTORY" });
  refreshHistory();
});

// "שלח טאב זה" — paste current tab's URL
$("currentTabBtn").addEventListener("click", async () => {
  const { url } = await chrome.runtime.sendMessage({ type: "GET_CURRENT_TAB_URL" });
  if (url && (url.startsWith("http://") || url.startsWith("https://"))) {
    $("urlInput").value = url;
    flash("URL מהטאב הנוכחי הוכנס ✓", "ok");
  } else {
    flash("לא ניתן לשלוח טאב זה", "err");
  }
});

// "פתח FetchPro" — show instructions instead of raw JSON
$("openApp").addEventListener("click", () => {
  const msg = document.createElement("div");
  msg.style.cssText = "position:fixed;inset:0;background:#070b12cc;display:flex;align-items:center;justify-content:center;z-index:999;font-family:Consolas,monospace";
  msg.innerHTML = `
    <div style="background:#0d1117;border:1px solid #1e2530;border-radius:8px;padding:20px 24px;max-width:300px;text-align:center;direction:rtl">
      <div style="font-size:24px;margin-bottom:8px">⬇</div>
      <div style="color:#e2e8f0;font-size:12px;font-weight:bold;margin-bottom:8px">הפעל את FetchPro</div>
      <div style="color:#4a5568;font-size:10px;line-height:1.6;margin-bottom:12px">
        1. פתח <code style="color:#00e5ff">fetchpro.py</code> ב-Python<br>
        2. או הרץ את <code style="color:#00e5ff">FetchPro.exe</code><br>
        3. הנקודה הירוקה תדלק אוטומטית
      </div>
      <button id="closeInstructions" style="background:#0a2a33;border:1px solid #00e5ff;color:#00e5ff;font-family:Consolas,monospace;font-size:10px;padding:6px 16px;cursor:pointer;border-radius:4px">סגור</button>
    </div>
  `;
  document.body.appendChild(msg);
  document.getElementById("closeInstructions").onclick = () => msg.remove();
  msg.onclick = e => { if (e.target === msg) msg.remove(); };
});

// ── init ──────────────────────────────────────────────────────────────────

refreshStatus();
refreshHistory();

// Poll connection status every 3s while popup is open
const statusInterval = setInterval(refreshStatus, 3000);
window.addEventListener("unload", () => clearInterval(statusInterval));
