// FetchPro Bridge — background service worker (v1.3)
// Intercepts Chrome downloads and routes them through FetchPro (port 9099)

const FETCHPRO_URL = "http://127.0.0.1:9099";
const STORAGE_KEY  = "fetchpro_enabled";
const HISTORY_KEY  = "fetchpro_history";
const MAX_HISTORY  = 50;

// ── helpers ────────────────────────────────────────────────────────────────

async function isEnabled() {
  const { fetchpro_enabled = true } = await chrome.storage.local.get(STORAGE_KEY);
  return fetchpro_enabled;
}

async function setEnabled(val) {
  await chrome.storage.local.set({ [STORAGE_KEY]: val });
  updateIcon(val);
}

function updateIcon(enabled) {
  // Use badge text instead of separate icon files (avoids missing-file errors)
  chrome.action.setBadgeText({ text: enabled ? "" : "OFF" });
  chrome.action.setBadgeBackgroundColor({ color: enabled ? "#00e5ff" : "#ff1744" });
  chrome.action.setBadgeTextColor({ color: "#000000" });
}

async function addToHistory(entry) {
  const { fetchpro_history = [] } = await chrome.storage.local.get(HISTORY_KEY);
  fetchpro_history.unshift(entry);
  if (fetchpro_history.length > MAX_HISTORY) fetchpro_history.length = MAX_HISTORY;
  await chrome.storage.local.set({ [HISTORY_KEY]: fetchpro_history });
}

async function sendToFetchPro(url) {
  const res = await fetch(`${FETCHPRO_URL}/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
    signal: AbortSignal.timeout(3000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

// ── download interception ──────────────────────────────────────────────────

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  if (!(await isEnabled())) return;

  const url = downloadItem.url || downloadItem.finalUrl || "";

  // Only intercept http/https/ftp — skip chrome-extension://, blob:, data: etc.
  if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("ftp://")) return;

  // Cancel the browser download immediately
  try {
    await chrome.downloads.cancel(downloadItem.id);
    await chrome.downloads.erase({ id: downloadItem.id });
  } catch (_) {
    // Download may have already finished or been removed — that's fine
  }

  let success = false;
  let errorMsg = "";
  try {
    await sendToFetchPro(url);
    success = true;
  } catch (e) {
    errorMsg = e.message?.includes("fetch") || e.name === "TimeoutError"
      ? "FetchPro לא פועל — פתח את התוכנה ונסה שוב"
      : e.message || "שגיאה לא ידועה";
  }

  await addToHistory({
    url,
    filename: downloadItem.filename || "",
    timestamp: Date.now(),
    success,
    error: errorMsg,
  });

  if (!success) {
    chrome.notifications.create(`fp-err-${Date.now()}`, {
      type:    "basic",
      iconUrl: "icons/icon48.png",
      title:   "FetchPro Bridge",
      message: errorMsg,
    });
  }
});

// ── message bus (from popup) ───────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {

      case "GET_STATUS": {
        const enabled = await isEnabled();
        let connected = false;
        try {
          const r = await fetch(`${FETCHPRO_URL}/status`, {
            signal: AbortSignal.timeout(1500),
          });
          connected = r.ok;
        } catch (_) {}
        sendResponse({ enabled, connected });
        break;
      }

      case "SET_ENABLED": {
        await setEnabled(msg.value);
        sendResponse({ ok: true });
        break;
      }

      case "GET_HISTORY": {
        const { fetchpro_history = [] } = await chrome.storage.local.get(HISTORY_KEY);
        sendResponse({ history: fetchpro_history });
        break;
      }

      case "CLEAR_HISTORY": {
        await chrome.storage.local.set({ [HISTORY_KEY]: [] });
        sendResponse({ ok: true });
        break;
      }

      case "SEND_URL": {
        const { url } = msg;
        let success = false, error = "";
        try {
          await sendToFetchPro(url);
          success = true;
          await addToHistory({ url, filename: "", timestamp: Date.now(), success: true, error: "" });
        } catch (e) {
          error = e.message || "שגיאת חיבור";
        }
        sendResponse({ success, error });
        break;
      }

      case "GET_CURRENT_TAB_URL": {
        // Get the URL of the currently active tab
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        sendResponse({ url: tab?.url || "" });
        break;
      }
    }
  })();
  return true; // keep channel open for async response
});

// ── context menus ─────────────────────────────────────────────────────────

function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id:       "fp-link",
      title:    "⬇ הורד קישור דרך FetchPro",
      contexts: ["link"],
    });
    chrome.contextMenus.create({
      id:       "fp-image",
      title:    "⬇ הורד תמונה דרך FetchPro",
      contexts: ["image"],
    });
    chrome.contextMenus.create({
      id:       "fp-video",
      title:    "⬇ הורד וידאו דרך FetchPro",
      contexts: ["video"],
    });
    chrome.contextMenus.create({
      id:       "fp-selection",
      title:    "⬇ הורד URL מסומן דרך FetchPro",
      contexts: ["selection"],
    });
    chrome.contextMenus.create({
      id:       "fp-page",
      title:    "⬇ שלח דף זה ל-FetchPro",
      contexts: ["page"],
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  let url = "";
  switch (info.menuItemId) {
    case "fp-link":      url = info.linkUrl               || ""; break;
    case "fp-image":     url = info.srcUrl                || ""; break;
    case "fp-video":     url = info.srcUrl                || ""; break;
    case "fp-selection": url = (info.selectionText || "").trim(); break;
    case "fp-page":      url = tab?.url                   || ""; break;
  }
  if (!url) return;

  if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("ftp://")) {
    chrome.notifications.create(`fp-invalid-${Date.now()}`, {
      type: "basic", iconUrl: "icons/icon48.png",
      title: "FetchPro Bridge",
      message: "הטקסט המסומן אינו קישור תקין",
    });
    return;
  }

  let success = false, errorMsg = "";
  try {
    await sendToFetchPro(url);
    success = true;
  } catch (e) {
    errorMsg = e.name === "TimeoutError"
      ? "FetchPro לא פועל — הפעל את התוכנה ונסה שוב"
      : (e.message || "שגיאה בשליחה");
  }

  await addToHistory({ url, filename: "", timestamp: Date.now(), success, error: errorMsg });

  chrome.notifications.create(`fp-ctx-${Date.now()}`, {
    type:    "basic",
    iconUrl: "icons/icon48.png",
    title:   "FetchPro Bridge",
    message: success
      ? `📥 נשלח: ${url.slice(0, 70)}`
      : errorMsg,
  });
});

// ── service worker init ────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(setupContextMenus);
chrome.runtime.onStartup.addListener(async () => {
  const enabled = await isEnabled();
  updateIcon(enabled);
  setupContextMenus();
});

// Re-init on wake (service workers can be killed and restarted)
(async () => {
  const enabled = await isEnabled();
  updateIcon(enabled);
})();
